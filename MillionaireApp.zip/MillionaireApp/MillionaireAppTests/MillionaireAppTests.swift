//
//  MillionaireAppTests.swift
//  MillionaireAppTests
//
//  Created by Alex A Diaz on 10/27/25.
//

import Testing
@testable import MillionaireApp

struct MillionaireAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
