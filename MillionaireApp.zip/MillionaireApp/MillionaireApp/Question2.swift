//
//  Question2.swift
//  MillionaireApp
//
//  Created by Alex A Diaz on 11/12/25.
//

import SwiftUI

struct Question2: View {
    @Binding var balance: Int   // <-- Accept binding from Question1
    @State private var selectedAnswer: String? = nil
    @State private var showNext = false
    @State private var showGameOver = false
    
    
    @State private var toast: Toast? = nil


    //Possible answers to choose from
    let answers = ["JK Rowling", "Dr.Seuss", "John F. Kennedy", "Jeff Kinney"]

    var body: some View {
        
        
        ZStack {
            // Background color gradient used for the application//
            LinearGradient(
                gradient: Gradient(colors: [Color.purple, Color.purple]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea(edges: .top)
            .ignoresSafeArea(edges: .bottom)
            
            
            
            
            VStack(spacing: 20) {
                //The title saying the question the user is currently on
                Text("Question 2")
                    .font(.title)
                    .bold()
                    .foregroundColor(.yellow)

                
                //Shows the current balance the user has after answering the first question correctly
                Text("Balance: \(balance)")
                    .bold()
                    .foregroundColor(.yellow)

                
                Divider()
                
                //The message that prompts what the question is about
                Text("Which of the following is not a famous author?")
                    .font(.title2)
                    .bold()
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                    .foregroundColor(.yellow)

                
                //Creates the list of answers in the format of a multiple choice question.//
                List(answers, id: \.self) { answer in
                    HStack {
                        Image(systemName:
                                selectedAnswer == answer
                              ? "largecircle.fill.circle"
                              : "circle"
                        )
                        .foregroundColor(selectedAnswer == answer ? .blue : .gray)
                        
                        Text(answer)
                            .bold()
                        Spacer()
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        selectedAnswer = answer
                    }
                }
                .scrollDisabled(true)
                
                
                //A next button is made and if the answer is correct, it increments the balance and navigates the user to the next question, else it navigates the user to the gamer over screen.//
                Button("Next") {
                    if selectedAnswer == "John F. Kennedy" {
                        balance += 100
                        
                        // Shows the toast message once correct answer is made.//
                        toast = Toast(
                            style: .success,
                            message: "This answer was correct!!!"
                        )
                        
                        // Delay navigation so the toast shows briefly
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                            showNext = true
                        }                    } else{
                        
                        showGameOver = true
                    }
                }
                .buttonStyle(.borderedProminent)
                .tint(.blue)
                .disabled(selectedAnswer == nil)
            }
            .padding()
            
            //Navigation to the next question.//
            .navigationDestination(isPresented: $showNext) {
                Question3(balance: $balance)
            }
            
            //Navigation to the game over page.//
             .navigationDestination(isPresented: $showGameOver){
                 GameOver()
            }
            
        }
        
        // Enables the toast to appear when the `toast` state is set.
        .toastView(toast: $toast)

        
    }
}

#Preview {
    NavigationStack{
        // Use .constant to provide a binding for the preview
        Question2(balance: .constant(0))
    }
}
