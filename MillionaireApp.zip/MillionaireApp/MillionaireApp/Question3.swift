//
//  Question3.swift
//  MillionaireApp
//
//  Created by Alex A Diaz on 11/21/25.
//

import SwiftUI

struct Question3: View {
    @Binding  var balance: Int
    @State private var selectedAnswer: String? = nil
    @State private var showNext = false
    @State private var showGameOver = false
    
    
    @State private var toast: Toast? = nil

    
    //List of answers the user will select from.//
    let answers = ["White Tiger", "White Rhino", "Dire Wolf", "Whtie Cheeta"]


    var body: some View {
        NavigationStack{
            
            ZStack {
                // Background color gradient used for the application//
                LinearGradient(
                    gradient: Gradient(colors: [Color.purple, Color.purple]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea(edges: .top)
                .ignoresSafeArea(edges: .bottom)
                
                
                VStack(spacing: 20){
                    
                    //The text informing the user that they are currently on the third question.//
                    Text("Question 3")
                        .bold()
                        .font(.title)
                        .foregroundColor(.yellow)

                    
                    //Shows the current balance a user has.//
                    Text("balance: \(balance)")
                        .bold()
                        .foregroundColor(.yellow)

                    
                    Divider()
                    
                    //The question the user has to answer at Question 3.//
                    Text("What is the current rarest animal in the world?")
                        .font(.title2)
                        .bold()
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .foregroundColor(.yellow)

                    
                    //The list of the answers array is shown in the form of a list and is designed to look like multiple choice questions.//
                    List(answers, id: \.self) { answer in
                        HStack {
                            Image(systemName:
                                    selectedAnswer == answer
                                  ? "largecircle.fill.circle"
                                  : "circle"
                            )
                            .foregroundColor(selectedAnswer == answer ? .blue : .gray)
                            
                            Text(answer).bold()
                            
                            Spacer()
                        }
                        .contentShape(Rectangle())
                        .onTapGesture {
                            selectedAnswer = answer
                        }
                    }
                    .scrollDisabled(true)
                    
                    //The "Next" button is made to send the user to either the next question incrementing their balance or it directs them to the GameOver page.//
                    Button("Next") {
                        if selectedAnswer == "White Rhino" {
                            balance += 300
                            
                            // Shows the toast message once correct answer is made.//
                            toast = Toast(
                                style: .success,
                                message: "This answer was correct!!!"
                            )
                            
                            // Delay navigation so the toast shows briefly
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                                showNext = true
                            }
                        } else{
                            
                            showGameOver = true
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.blue)
                    .disabled(selectedAnswer == nil)
                }
                .padding()
                
                //Navigation to the next question.//
                .navigationDestination(isPresented: $showNext) {
                    Question4(balance: $balance)
                }
                
                //Navigation to the game over page.//
                .navigationDestination(isPresented: $showGameOver){
                    GameOver()
                }
            }
            
            // Enables the toast to appear when the `toast` state is set.//
            .toastView(toast: $toast)

                
        }
    }
}

#Preview {
    NavigationStack{
        Question3(balance: .constant(0))
    }
}
