//
//  GameOver.swift
//  MillionaireApp
//
//  Created by Alex A Diaz on 11/17/25.
//

import SwiftUI

struct GameOver: View {
    var body: some View {
        NavigationStack{
            
            
            ZStack {
                // Background color gradient used for the application//
                LinearGradient(
                    gradient: Gradient(colors: [Color.purple, Color.purple]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea(edges: .top)
                .ignoresSafeArea(edges: .bottom)
                
            VStack{
                
                //Title message that lets the user know they lost.//
                Text("GAME OVER")
                        .font(.title)
                        .bold()
                        .foregroundColor(.yellow)
                    
                    
                    Divider()
                    Spacer()
                    
                //message letting the user know they can try again//
                    Text("You win no money, better luck next time!")
                        .bold()
                        .font(.title)
                        .foregroundColor(.yellow)
                    
                    
                    Spacer()
                
                Divider()
                    
                    HStack{
                        
                        //Play again button that will direct the user back to the first question when tapped on//
                        NavigationLink(destination: Question1()){
                            Text("Play Again")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                        
                        
                        //A exit button is made to direct the user to the very beginning of the application if they do not want to play anymore.//
                        NavigationLink(destination: ContentView()){
                            Text("Exit")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                    }
                    
                }
                
            }
            
        }
        
    }
}

#Preview {
    GameOver()
}
