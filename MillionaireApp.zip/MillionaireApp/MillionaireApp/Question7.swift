//
//  MillionaireApp

//  Question7.swift

//  Created by Alex A Diaz on 11/21/25.
//

import SwiftUI

struct Question7: View {
    @Binding var balance: Int
    @State private var selectedAnswer: String? = nil
    @State private var showNext = false
    @State private var showGameOver = false
    
    
    @State private var toast: Toast? = nil

    
    let answers = ["Creed", "Nirvana", "Kiss", "Foo Fighters"]
    
    var body: some View {
        
        ZStack {
            // Background color gradient used for the application//
            LinearGradient(
                gradient: Gradient(colors: [Color.purple, Color.purple]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea(edges: .top)
            .ignoresSafeArea(edges: .bottom)
            
            VStack(spacing: 20) {
                
                Text("Question 7")
                    .bold()
                    .font(.title)
                    .foregroundColor(.yellow)

                
                Text("Balance: \(balance)")
                    .bold()
                    .foregroundColor(.yellow)

                
                Divider()
                
                Text("What famous band wrote the song There goes my hero?")
                    .font(.title2)
                    .bold()
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                    .foregroundColor(.yellow)

                
                List(answers, id: \.self) { answer in
                    HStack {
                        Image(systemName:
                                selectedAnswer == answer
                              ? "largecircle.fill.circle"
                              : "circle"
                        )
                        .foregroundColor(selectedAnswer == answer ? .blue : .gray)
                        
                        Text(answer).bold()
                        Spacer()
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        selectedAnswer = answer
                    }
                }
                .scrollDisabled(true)
                
                //A next button is made and if the answer is correct, it increments the balance and navigates the user to the next question, else it navigates the user to the gamer over screen.//

                Button("Next") {
                    if selectedAnswer == "Foo Fighters" {
                        balance += 5000
                        
                        // Shows the toast message once correct answer is made.//
                        toast = Toast(
                            style: .success,
                            message: "This answer was correct!!!"
                        )
                        
                        // Delay navigation so the toast shows briefly
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                            showNext = true
                        }


                    } else {
                        showGameOver = true
                    }
                }
                .buttonStyle(.borderedProminent)
                .tint(.blue)
                .disabled(selectedAnswer == nil)
                
            }
            .padding()
            
            
            //Navigation to the next question.//
            .navigationDestination(isPresented: $showNext) {
                Question8(balance: $balance)
            }
            
            //Navigation to the game over page.//
            .navigationDestination(isPresented: $showGameOver) {
                GameOver()
            }
        }
        
        // Enables the toast to appear when the `toast` state is set.
        .toastView(toast: $toast)

    }
}

#Preview {
    NavigationStack {
        Question7(balance: .constant(0))
    }
}
