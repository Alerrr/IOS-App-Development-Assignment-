//
//  MillionaireAppApp.swift
//  MillionaireApp
//
//  Created by Alex A Diaz on 10/27/25.
//

import SwiftUI

@main
struct MillionaireAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
