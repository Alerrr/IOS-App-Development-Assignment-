//
//  Results.swift
//  MillionaireApp
//
//  Created by Alex A Diaz on 11/12/25.
//

import SwiftUI

struct Results: View {
    @Binding var balance: Int

    var body: some View {
        NavigationStack {
            
            
            ZStack {
                // Background color gradient used for the application//
                LinearGradient(
                    gradient: Gradient(colors: [Color.purple, Color.purple]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea(edges: .top)
                .ignoresSafeArea(edges: .bottom)
                
                VStack(spacing: 20) {
                    Text("Results")
                        .font(.title)
                        .bold()
                        .foregroundColor(.yellow)
                    
                    Divider()
                    
                    //Message displaying that the user has won the game.//
                    Text("CONGRATS YOU HAVE WON 1000000 DOLLARS!!!!! Here is your new balance......")
                        .font(.title)
                        .bold()
                        .foregroundColor(.yellow)
                    
                    Spacer()
                    
                    //Shows the user the balance that was won through playing the game.//
                    Text("Balance: $\(balance)")
                        .font(.title)
                        .bold()
                        .foregroundColor(.yellow)

                    
                    Spacer()
                    
                    Text("Thanks for playing!")
                        .foregroundColor(.yellow)
                        .font(.title2)
                        .bold()

                    
                    //The home button will take the user back to the very start of the application//
                    NavigationLink(destination: ContentView()) {
                        Text("Home")
                            .bold()
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                }
                .padding()
            }
        }
    }
}

#Preview {
    Results(balance: .constant(0))
}
