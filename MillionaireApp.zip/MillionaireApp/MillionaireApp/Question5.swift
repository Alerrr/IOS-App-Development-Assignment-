//
//  Question5.swift
//  MillionaireApp
//
//  Created by Alex A Diaz on 11/21/25.
//

import SwiftUI

struct Question5: View {
    @Binding var balance: Int
    @State private var selectedAnswer: String? = nil
    @State private var showNext = false
    @State private var showGameOver = false
    
    
    @State private var toast: Toast? = nil

    
    let answers = ["Hurricane Patricia", "Hurricane Sandy", "Hurricane Katrina", "Hurricane Andrew"]
    
    var body: some View {
        
        
        ZStack {
            // Background color gradient used for the application//
            LinearGradient(
                gradient: Gradient(colors: [Color.purple, Color.purple]),
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea(edges: .top)
            .ignoresSafeArea(edges: .bottom)
            
            VStack(spacing: 20) {
                
                Text("Question 5")
                    .bold()
                    .font(.title)
                    .foregroundColor(.yellow)

                
                Text("Balance: \(balance)")
                    .bold()
                    .foregroundColor(.yellow)

                
                Divider()
                
                Text("What hurricane was the strongest ever recorded?")
                    .font(.title2)
                    .bold()
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                    .foregroundColor(.yellow)

                
                List(answers, id: \.self) { answer in
                    HStack {
                        Image(systemName:
                                selectedAnswer == answer
                              ? "largecircle.fill.circle"
                              : "circle"
                        )
                        .foregroundColor(selectedAnswer == answer ? .blue : .gray)
                        
                        Text(answer).bold()
                        Spacer()
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        selectedAnswer = answer
                    }
                }
                .scrollDisabled(true)
                
                //A next button is made and if the answer is correct, it increments the balance and navigates the user to the next question, else it navigates the user to the gamer over screen.//

                Button("Next") {
                    if selectedAnswer == "Hurricane Patricia" {
                        balance += 1000
                        
                        // Shows the toast message once correct answer is made.//
                        toast = Toast(
                            style: .success,
                            message: "This answer was correct!!!"
                        )
                        
                        // Delay navigation so the toast shows briefly
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                            showNext = true
                        }



                    } else {
                        showGameOver = true
                    }
                }
                .buttonStyle(.borderedProminent)
                .tint(.blue)
                .disabled(selectedAnswer == nil)
                
            }
            .padding()
            
            //Navigation to the next question.//
            .navigationDestination(isPresented: $showNext) {
                Question6(balance: $balance)
            }
            
            
            //Navigation to the game over page.//
            .navigationDestination(isPresented: $showGameOver) {
                GameOver()
            }
        }
        .toastView(toast: $toast)

        
    }
}

#Preview {
    NavigationStack {
        Question5(balance: .constant(0))
    }
}
