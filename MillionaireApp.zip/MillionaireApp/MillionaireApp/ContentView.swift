//
//  ContentView.swift
//  MillionaireApp
//
//  Created by Alex A Diaz on 10/27/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack{
            ZStack {
                
                // Background color gradient used for the application//
                LinearGradient(
                    gradient: Gradient(colors: [Color.purple, Color.purple]),
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea(edges: .top)
                .ignoresSafeArea(edges: .bottom)
                
                VStack {
                    
                    //Title message displayed to the user at the start of the screen.//
                    Text("Welcome to Who Wants To Be A Millionaire!!")
                        .font(.title)
                        .bold()
                        .foregroundColor(.yellow)

                    Spacer()
                    Divider()
                    
                    //Image that appears at the center screen of the homepage//
                    Image("millionaire")
                        .resizable()
                        .scaledToFit()
                        .foregroundStyle(.tint)
                        .foregroundColor(.yellow)

                    //Message prompting the user to hit the start button below.//
                    Text("Press below to start!")
                        .font(.title3)
                        .bold()
                        .foregroundColor(.yellow)

                    
                    
                    //A start button that navigates the user to the first question within the application.//
                    NavigationLink(destination: Question1()){
                        Text("Start")
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(8)
                    
                }
                .padding()
            }
            
        }
    }
}

#Preview {
    ContentView()
}
