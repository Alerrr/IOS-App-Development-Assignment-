//
//  WeatherAppApp.swift
//  WeatherApp
//
//  Created by Alex A Diaz on 9/29/25.
//

import SwiftUI

@main
struct WeatherAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
