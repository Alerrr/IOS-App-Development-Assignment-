//
//  ContentView.swift
//  WeatherApp
//
//  Created by Alex A Diaz on 9/29/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        
            HStack{
                
            DayForecast(day: "Mon", high: 70, low: 50, isRainy: false)
            
            DayForecast(day: "Tue", high: 60, low: 40, isRainy: true)
            
            DayForecast(day: "Wed", high: 74, low: 62, isRainy: true)
            
            DayForecast(day: "Thu", high: 88, low: 65, isRainy: false)
            
            DayForecast(day: "Fri", high: 76, low: 67, isRainy: true)
            
            DayForecast(day: "Sat", high: 80, low: 62, isRainy: false)
            
            DayForecast(day: "Sun", high: 81, low: 62, isRainy: false)
                

        }
        
        
            .padding()
        
        .background{
            Image("CloudBG")
                .resizable()
                .scaledToFill()
                .edgesIgnoringSafeArea(.all)
                .padding(.top, 150)
                
                
            
                
            Text("Weather App")
                .fontWeight(Font.Weight.bold)
                .font(.title)
                .padding(.top, -180)
            
                
        }
        
        
    
        
    }
}

#Preview {
    ContentView()
}

struct DayForecast: View {
    let day: String
    let high: Int
    let low: Int
    let isRainy: Bool
    
    var iconName: String{
        if isRainy{
            return "cloud.rain.fill"
        }else{
            return "sun.max.fill"
        }
    }
    
    var iconColor: Color{
        if isRainy{
            return Color.blue
        }else{
            return Color.yellow
        }
    }
    
    
 
    
    
    var body: some View {
        VStack {
            
            Text(day)
                .font(Font.headline)
            Image(systemName: iconName)
                .foregroundStyle(iconColor)
                .font(Font.largeTitle)
            Text("High: \(high)")
                .fontWeight(Font.Weight.semibold)
            Text("Low: \(low)")
                .fontWeight(Font.Weight.medium)
                .foregroundStyle(Color.secondary)
        }
    }
}
