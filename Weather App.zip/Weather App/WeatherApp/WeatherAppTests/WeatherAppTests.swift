//
//  WeatherAppTests.swift
//  WeatherAppTests
//
//  Created by Alex A Diaz on 9/29/25.
//

import Testing
@testable import WeatherApp

struct WeatherAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
