//
//  ContentView.swift
//  LunarZodiacArray
//
//  Created by Alex A Diaz on 9/30/25.
//

import SwiftUI

struct ContentView: View {
    
    //String Array made for Zodiac Animals//
    var animalNames = ["RAT", "OX", "TIGER", "RABBIT", "DRAGON", "SNAKE", "HORSE", "GOAT", "MONKEY", "ROOSTER", "DOG", "PIG"]
    
    //Sets the currentYear to 2023//
    @State private var currentYear = 2023
    
    //sets the current animal image with the correctr name and year
    var currentAnimal: String{
        var index = (currentYear - 2020) % 12
        return animalNames [(index + 12) % 12]
    }
    var body: some View {
        
        //Prints out the year 2023 as text//
        Text(String(currentYear))
            .font(.largeTitle)
            .fontWeight(.black)
            .foregroundColor(Color.red)
        
        //Pushes everything else down to the bottom screen of the application
            Spacer()
        
        //Displays the current image for the animals on screen
        Image(currentAnimal)
            .resizable()
            .aspectRatio(contentMode: .fit)
        
        //Displays the text for the current animal shown on screen
        Text(currentAnimal)
            .font(.largeTitle)
            .fontWeight(.black)
        
            
        
        
        //A horizontal stack was made for the buttons
        HStack{
            
            //This makes the button go back by one year every press
            Button("<"){
                currentYear -= 1
            }

            .font(.largeTitle)
                .fontWeight(.black)
                .foregroundColor(.white)
                .padding()
                .background(Color.red)
                .cornerRadius(8)
            Spacer()
                .frame(width: 250)
                

            //This makes the button go forward by one year every press
            Button(">"){
                currentYear += 1
            }
            .font(.largeTitle)
                .fontWeight(.black)
                .foregroundColor(.white)
                .padding()
                .background(Color.red)
                .cornerRadius(8)

        }
        
        VStack {
            
            
        }
        .padding(.horizontal)
    }
    
}

#Preview {
    ContentView()
}
