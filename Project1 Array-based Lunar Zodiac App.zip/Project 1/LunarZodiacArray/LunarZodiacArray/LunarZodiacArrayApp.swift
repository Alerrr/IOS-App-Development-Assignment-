//
//  LunarZodiacArrayApp.swift
//  LunarZodiacArray
//
//  Created by Alex A Diaz on 10/7/25.
//

import SwiftUI

@main
struct LunarZodiacArrayApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
