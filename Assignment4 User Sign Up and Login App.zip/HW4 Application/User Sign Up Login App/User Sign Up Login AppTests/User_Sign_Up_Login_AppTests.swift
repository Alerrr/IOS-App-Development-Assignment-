//
//  User_Sign_Up_Login_AppTests.swift
//  User Sign Up Login AppTests
//
//  Created by Alex A Diaz on 10/15/25.
//

import Testing
@testable import User_Sign_Up_Login_App

struct User_Sign_Up_Login_AppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
