//
//  ContentView.swift
//  User Sign Up Login App
//
//  Created by Alex A Diaz on 10/15/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            
        }
        
        HStack(){
            loginScreen()
        }
        
        
        
        
        .padding()
    }
}

#Preview {
    ContentView()
}
