//
//  welcomeScreen.swift
//  User Sign Up Login App
//
//  Created by Alex A Diaz on 11/2/25.
//

import SwiftUI

struct welcomeScreen: View {
    let name: String
    var body: some View {
        Text("Welcome")
            .font(.largeTitle)
            .bold()
        
        Text(name)
            .font(.title2)
    }
}


#Preview {
    welcomeScreen(name: "User")
}
