//
//  signUpScreen.swift
//  User Sign Up Login App
//
//  Created by Alex A Diaz on 11/2/25.
//

import SwiftUI

struct signUpScreen: View {
    
    //These variables are used to store the info from different screens so information can be saved when signing up and logging in
    @Binding var savedUsername: String
    @Binding var savedPassword: String
    
    @State private var newUsername = ""
    @State private var newPassword = ""
    @State private var confirmPassword = ""
    
    @State private var errorMessage = ""
    
    var body: some View {
        NavigationStack {
            VStack(){
                
                //Sign up title text is made
                Text("Sign Up")
                    .font(.title)
                    .bold()
                
                //Text box made for the new username
                TextField("Username", text: $newUsername)
                    .textFieldStyle(.roundedBorder)
                    .autocapitalization(.none)
                    .disableAutocorrection(true)
                
                //text box made for the new password
                TextField("Password", text: $newPassword)
                    .textFieldStyle(.roundedBorder)
                
                //Text box is made to confirm the password
                TextField("Confirm Password", text: $confirmPassword)
                    .textFieldStyle(.roundedBorder)
                
                
                HStack{
                    // Sign Up button was created
                    Button("Sign Up") {
                        //if there is no username, password, and confirm password entered an error messagae occurs.
                        if newUsername.isEmpty || newPassword.isEmpty || confirmPassword.isEmpty {
                            errorMessage = "All fields must be entered."
                            //if the password and confirm password are different, an error message occurs.
                        } else if newPassword != confirmPassword {
                            errorMessage = "Passwords do not match."
                        } else {
                            // else it will save the information entered from sign up
                            savedUsername = newUsername
                            savedPassword = newPassword
                            errorMessage = "Account made. Please Login"
                            
                        }
                    }
                    .buttonStyle(.bordered)
                    
                    // Clear Input button was created for the screen to remove all information from each text box
                    Button("Clear Input") {
                        newUsername = ""
                        newPassword = ""
                        confirmPassword = ""
                        errorMessage = ""
                    }
                    .buttonStyle(.bordered)
                    
                    if !errorMessage.isEmpty {
                        
                        Text(errorMessage)
                        
                    }
                }
                
                //A button is made to go to the login page
                NavigationLink("Go to Login Page", destination: loginScreen())
                    .buttonStyle(.bordered)
                
            }
            .padding()
        }
    }
}

//.constant("") is used to give a read only fake value for the  binding variables so the view can be previewed on the canvas.

#Preview {
    signUpScreen(savedUsername: .constant(""), savedPassword: .constant(""))
}
