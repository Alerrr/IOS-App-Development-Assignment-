//
//  loginScreen.swift
//  User Sign Up Login App
//
//  Created by Alex A Diaz on 10/15/25.
//

import SwiftUI

struct loginScreen: View {
    //The user entering their information
    @State private var enteredUsername = ""
    @State private var enteredPassword = ""
    
    // This information is gets saved once the user makes an account in the Sign Up page
    @State private var savedUsername = ""
    @State private var savedPassword = ""
    
    //These variables are made for when the user enters the wrong information
    @State private var errorMessage = ""
    @State private var isLoggedIn = false
    
    var body: some View {
        NavigationStack {
            VStack{
                //Login button was created
                Text("Login")
                    .font(.title)
                    .bold()
            //Username text box
                TextField("Username", text: $enteredUsername)
                    .textFieldStyle(.roundedBorder)
                    .autocapitalization(.none)
                    .disableAutocorrection(true)
                
                //Password text box
                TextField("Password", text: $enteredPassword)
                    .textFieldStyle(.roundedBorder)
                
                }
                
            //Horizontal stack was made for the login and sign up buttons
                HStack {
                    
                    //If the user tries to hit the login button without the signed up credentials then it will give an error.
                    Button("Login") {
                        if savedUsername.isEmpty || savedPassword.isEmpty {
                            errorMessage = "No account found. Please create one."
                            isLoggedIn = false
                            return
                        }
                        
                        //If they did enter the same credentials as the sign up page then it would be true and allowed to login
                        if enteredUsername == savedUsername && enteredPassword == savedPassword {
                            errorMessage = ""
                            isLoggedIn = true
                        } else {
                            errorMessage = "Incorrect username or password."
                        }
                    }
                    .buttonStyle(.bordered)
                    //This disables the login button off the application start so the user has to make a new account first before logging in
                    .disabled(savedUsername.isEmpty || savedPassword.isEmpty)
                    
                    //When the sign up button is hit it navigates to the Sign Up page
                    NavigationLink("Sign Up") {
                        signUpScreen(savedUsername: $savedUsername, savedPassword: $savedPassword)
                    }
                    .buttonStyle(.bordered)
                }
                
                // Navigates to welcome screen if login information is correct
                NavigationLink(destination: welcomeScreen(name: enteredUsername), isActive: $isLoggedIn) {
                    EmptyView()
                
            }
            .padding()
        }
    }
}

#Preview {
    loginScreen()
}
