//
//  User_Sign_Up_Login_AppApp.swift
//  User Sign Up Login App
//
//  Created by Alex A Diaz on 10/15/25.
//

import SwiftUI

@main
struct User_Sign_Up_Login_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
